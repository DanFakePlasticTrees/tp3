#include "LinkedList.h"

int parser_AppFromText(FILE* pFile, LinkedList* pApp);

int parser_AppFavFromText(FILE* pFile, LinkedList* pApp);

